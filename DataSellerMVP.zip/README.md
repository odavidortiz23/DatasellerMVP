
# DataSellerMVP

Data-Driven SaaS para ayudar a tiendas Shopify a interpretar sus datos y tomar mejores decisiones.

## Estructura

- `/backend`: API y lógica de negocio.
- `/frontend`: Dashboard React.
- `/docs`: Documentación de decisiones y procesos.
- `/scraping`: Scripts para obtener datos externos (competencia y tendencias).

## Primera Fase

- [ ] Conectar con Shopify Admin API.
- [ ] Crear primer dashboard.
- [ ] Generar primeras recomendaciones.
